
import CuveeList from "@/components/cuvees/CuveeList";

const CuveesPage = () => {
  return <CuveeList />;
};

export default CuveesPage;
