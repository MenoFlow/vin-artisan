
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CuveeCard from "./CuveeCard";
import { toast } from "sonner";

// Type pour une cuvée
interface Cuvee {
  id: string;
  nom: string;
  annee: string;
  type: string;
  cepage: string;
  prix: string;
  stock: string;
  description?: string;
  image?: string;
}

const CuveeList = () => {
  // États pour les cuvées et le filtrage
  const [cuvees, setCuvees] = useState<Cuvee[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(false);

  // Images par défaut pour chaque type de vin
  const defaultImages = {
    "Rouge": "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80",
    "Blanc": "https://images.unsplash.com/photo-1566754436893-89894b67d6ba?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80",
    "Rose": "https://images.unsplash.com/photo-1558682575-d1b8e0caafe0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1548&q=80",
    "Petillant": "https://images.unsplash.com/photo-1590082871875-849310c4d415?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80",
    "default": "https://images.unsplash.com/photo-1586370434639-0fe43b4daa6d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80"
  };

  // Charger les cuvées depuis le localStorage ou l'API
  useEffect(() => {
    loadCuvees();
  }, []);

  const loadCuvees = async () => {
    setLoading(true);
    try {
      // Version localStorage
      const savedCuvees = localStorage.getItem('cuvees');
      if (savedCuvees) {
        try {
          const parsedCuvees = JSON.parse(savedCuvees);
          // Ajouter une image par défaut si nécessaire
          const cuveesWithImages = parsedCuvees.map((cuvee: Cuvee) => ({
            ...cuvee,
            image: cuvee.image || defaultImages[cuvee.type as keyof typeof defaultImages] || defaultImages.default
          }));
          setCuvees(cuveesWithImages);
        } catch (error) {
          console.error("Erreur lors du chargement des cuvées:", error);
          setCuvees([]);
        }
      } else {
        // Données initiales si aucune cuvée n'existe
        const initialCuvees = [
          {
            id: "1",
            nom: "Grande Réserve",
            annee: "2020",
            type: "Rouge",
            cepage: "Cabernet Sauvignon",
            prix: "24.50",
            stock: "42",
            description: "Un vin puissant aux tanins veloutés",
            image: defaultImages.Rouge
          },
          {
            id: "2",
            nom: "Cuvée Élégance",
            annee: "2021",
            type: "Blanc",
            cepage: "Chardonnay",
            prix: "18.90",
            stock: "65",
            description: "Un blanc sec aux notes d'agrumes et de fleurs blanches",
            image: defaultImages.Blanc
          },
          {
            id: "3",
            nom: "Rosé des Collines",
            annee: "2022",
            type: "Rose",
            cepage: "Grenache, Cinsault",
            prix: "14.50",
            stock: "8",
            description: "Un rosé fruité et rafraîchissant",
            image: defaultImages.Rose
          },
          {
            id: "4",
            nom: "Pétillant Nature",
            annee: "2021",
            type: "Petillant",
            cepage: "Chenin",
            prix: "22.00",
            stock: "0",
            description: "Une bulle naturelle vive et tendue",
            image: defaultImages.Petillant
          },
        ];
        
        // Sauvegarder les cuvées initiales
        localStorage.setItem('cuvees', JSON.stringify(initialCuvees));
        setCuvees(initialCuvees);
        
        // Synchroniser avec le catalogue
        syncWithCatalogue(initialCuvees);
      }
      
      // Version API REST (à décommenter pour utilisation avec backend)
      /*
      try {
        const response = await fetch('/api/cuvees');
        if (!response.ok) throw new Error('Erreur lors de la récupération des cuvées');
        
        const data = await response.json();
        // Transformer les données de l'API au format attendu par le composant
        const formattedCuvees = data.map((item: any) => ({
          id: item.id,
          nom: item.nom,
          annee: item.annee?.toString() || '',
          type: item.type,
          cepage: item.cepage || '',
          prix: item.prix?.toString() || '0',
          stock: item.stock?.toString() || '0',
          description: item.description || '',
          image: item.image || defaultImages[item.type as keyof typeof defaultImages] || defaultImages.default
        }));
        
        setCuvees(formattedCuvees);
      } catch (error) {
        console.error('Erreur API:', error);
        toast.error("Erreur lors du chargement des cuvées depuis l'API");
      }
      */
    } catch (error) {
      console.error("Erreur générale:", error);
      toast.error("Erreur lors du chargement des cuvées");
    } finally {
      setLoading(false);
    }
  };

  // Synchroniser les cuvées avec le catalogue
  const syncWithCatalogue = (updatedCuvees: Cuvee[]) => {
    // Convertir les cuvées au format attendu par le catalogue
    const catalogueItems = updatedCuvees.map(cuvee => ({
      id: cuvee.id,
      nom: cuvee.nom,
      annee: cuvee.annee,
      type: cuvee.type,
      cepage: cuvee.cepage,
      prix: cuvee.prix,
      description: cuvee.description || "",
      stock: cuvee.stock,
      image: cuvee.image || defaultImages[cuvee.type as keyof typeof defaultImages] || defaultImages.default
    }));
    
    // Sauvegarder dans le localStorage pour le catalogue
    localStorage.setItem('catalogueWines', JSON.stringify(catalogueItems));
  };

  // Filtrer les cuvées en fonction de la recherche
  const filteredCuvees = cuvees.filter(
    (cuvee) =>
      cuvee.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cuvee.annee.includes(searchTerm) ||
      cuvee.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cuvee.cepage.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Supprimer une cuvée
  const handleDelete = async (id: string) => {
    try {
      setLoading(true);
      
      // Version localStorage
      const updatedCuvees = cuvees.filter((cuvee) => cuvee.id !== id);
      setCuvees(updatedCuvees);
      
      // Mettre à jour le localStorage
      localStorage.setItem('cuvees', JSON.stringify(updatedCuvees));
      
      // Synchroniser avec le catalogue
      syncWithCatalogue(updatedCuvees);
      
      toast.success("Cuvée supprimée avec succès", {
        description: "La cuvée a été supprimée de la base de données."
      });
      
      // Version API REST (à décommenter pour utilisation avec backend)
      /*
      try {
        const response = await fetch(`/api/cuvees/${id}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Erreur lors de la suppression de la cuvée');
        
        // Mettre à jour l'état local après confirmation de la suppression
        const updatedCuvees = cuvees.filter((cuvee) => cuvee.id !== id);
        setCuvees(updatedCuvees);
        
        // Synchroniser avec le catalogue
        syncWithCatalogue(updatedCuvees);
        
        toast.success("Cuvée supprimée avec succès", {
          description: "La cuvée a été supprimée de la base de données."
        });
      } catch (error) {
        console.error('Erreur API:', error);
        toast.error("Erreur lors de la suppression de la cuvée");
      }
      */
    } catch (error) {
      console.error("Erreur lors de la suppression:", error);
      toast.error("Erreur lors de la suppression de la cuvée");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h1 className="text-2xl font-bold">Gestion des cuvées</h1>
        <div className="flex w-full sm:w-auto gap-2">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Rechercher..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <Button asChild>
            <Link to="/cuvees/ajouter">
              <Plus size={18} className="mr-1" /> Ajouter
            </Link>
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">Chargement des cuvées...</p>
        </div>
      ) : filteredCuvees.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">Aucune cuvée trouvée</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredCuvees.map((cuvee) => (
            <CuveeCard
              key={cuvee.id}
              id={cuvee.id}
              nom={cuvee.nom}
              annee={cuvee.annee}
              type={cuvee.type}
              cepage={cuvee.cepage}
              prix={cuvee.prix}
              stock={cuvee.stock}
              image={cuvee.image}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default CuveeList;
