
import { useState } from "react";
import { toast } from "sonner";
import CuveeForm from "@/components/cuvees/CuveeForm";
import { v4 as uuidv4 } from 'uuid';

const AddCuveePage = () => {
  const addCuvee = async (cuveeData: any) => {
    // Version localStorage
    try {
      const savedCuvees = localStorage.getItem('cuvees');
      const cuvees = savedCuvees ? JSON.parse(savedCuvees) : [];
      
      // Ajouter un ID unique et la date de création
      const newCuvee = {
        id: uuidv4(),
        ...cuveeData,
        dateCreation: new Date().toISOString()
      };
      
      cuvees.push(newCuvee);
      localStorage.setItem('cuvees', JSON.stringify(cuvees));
      toast.success("Cuvée ajoutée avec succès");
      return newCuvee;
      
    } catch (error) {
      console.error("Erreur lors de l'ajout:", error);
      toast.error("Erreur lors de l'ajout de la cuvée");
      throw error;
    }
    
    // API call (à décommenter pour utiliser avec backend)
    // try {
    //   const response = await fetch('/api/cuvees', {
    //     method: 'POST',
    //     headers: {
    //       'Content-Type': 'application/json',
    //     },
    //     body: JSON.stringify(cuveeData),
    //   });
    //   
    //   if (!response.ok) {
    //     throw new Error('Erreur lors de l\'ajout');
    //   }
    //   
    //   const data = await response.json();
    //   toast.success("Cuvée ajoutée avec succès");
    //   return data;
    // } catch (error) {
    //   console.error("Erreur API:", error);
    //   toast.error("Erreur lors de l'ajout de la cuvée");
    //   throw error;
    // }
  };

  return <CuveeForm onSubmit={addCuvee} />;
};

export default AddCuveePage;
