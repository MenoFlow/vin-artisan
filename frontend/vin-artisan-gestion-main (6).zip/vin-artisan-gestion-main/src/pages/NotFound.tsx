
import { ArrowLeft, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const NotFound = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <AlertTriangle size={64} className="text-wine mb-4" />
      <h1 className="text-4xl font-bold mb-4">404</h1>
      <p className="text-xl text-muted-foreground mb-8">
        Page non trouvée
      </p>
      <Button onClick={() => navigate("/")}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Retour à l'accueil
      </Button>
    </div>
  );
};

export default NotFound;
