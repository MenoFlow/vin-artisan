
/**
 * Service pour gérer les pays partenaires
 */

// Liste des pays partenaires par défaut
const DEFAULT_PARTNER_COUNTRIES = [
  { code: 'FR', name: 'France' },
  { code: 'BE', name: 'Belgique' },
  { code: 'CH', name: 'Suisse' },
  { code: 'LU', name: 'Luxembourg' },
  { code: 'DE', name: 'Allemagne' },
  { code: 'IT', name: 'Italie' },
  { code: 'ES', name: 'Espagne' },
];

export interface Country {
  code: string;
  name: string;
}

/**
 * Récupère la liste des pays partenaires
 */
export const getPartnerCountries = (): Country[] => {
  const savedCountries = localStorage.getItem('partnerCountries');
  if (savedCountries) {
    try {
      return JSON.parse(savedCountries);
    } catch (error) {
      console.error("Erreur lors de la lecture des pays partenaires:", error);
      return DEFAULT_PARTNER_COUNTRIES;
    }
  }
  return DEFAULT_PARTNER_COUNTRIES;
};

/**
 * Sauvegarde une nouvelle liste de pays partenaires
 */
export const savePartnerCountries = (countries: Country[]): void => {
  localStorage.setItem('partnerCountries', JSON.stringify(countries));
};

/**
 * Ajoute un pays à la liste des partenaires
 */
export const addPartnerCountry = (country: Country): void => {
  const countries = getPartnerCountries();
  if (!countries.some(c => c.code === country.code)) {
    countries.push(country);
    savePartnerCountries(countries);
  }
};

/**
 * Supprime un pays de la liste des partenaires
 */
export const removePartnerCountry = (countryCode: string): void => {
  const countries = getPartnerCountries();
  const updatedCountries = countries.filter(c => c.code !== countryCode);
  savePartnerCountries(updatedCountries);
};

/**
 * Vérifie si le pays est partenaire
 */
export const isPartnerCountry = (countryCode: string): boolean => {
  const countries = getPartnerCountries();
  return countries.some(c => c.code.toUpperCase() === countryCode.toUpperCase());
};

/**
 * Vérifie la géolocalisation de l'utilisateur et si son pays est partenaire
 */
export const checkUserCountryIsPartner = async (): Promise<{
  isPartner: boolean;
  country?: { code: string; name: string };
  error?: string;
}> => {
  try {
    const response = await fetch('https://ipapi.co/json/');
    if (!response.ok) {
      throw new Error('Impossible de déterminer la localisation');
    }
    
    const data = await response.json();
    const countryCode = data.country_code;
    const countryName = data.country_name;
    
    if (!countryCode) {
      throw new Error('Pays non détecté');
    }
    
    const isPartner = isPartnerCountry(countryCode);
    
    return {
      isPartner,
      country: { 
        code: countryCode,
        name: countryName
      }
    };
  } catch (error) {
    console.error("Erreur lors de la vérification du pays:", error);
    return {
      isPartner: false,
      error: error instanceof Error ? error.message : 'Erreur inconnue'
    };
  }
};
