
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Search, Filter, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { generateInvoicePDF, fetchInvoices, deleteInvoice } from "@/services/invoiceService";
import { toast } from "sonner";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export interface InvoiceItem {
  id: string;
  product: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export interface Invoice {
  id: string;
  customerName: string;
  customerEmail: string;
  date: string;
  dueDate: string;
  items: InvoiceItem[];
  totalAmount: number;
  status: "paid" | "pending";
  userId?: string;
}

const FacturesPage = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState("all");
  const [showNewInvoiceDialog, setShowNewInvoiceDialog] = useState(false);
  const [loading, setLoading] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [invoiceToDelete, setInvoiceToDelete] = useState<string | null>(null);
  
  useEffect(() => {
    loadInvoices();
  }, []);
  
  const loadInvoices = async () => {
    try {
      setLoading(true);
      // Version localStorage
      const savedInvoices = localStorage.getItem('invoices');
      
      if (savedInvoices) {
        const parsedInvoices = JSON.parse(savedInvoices);
        // Valider et normaliser les données
        const validInvoices = parsedInvoices.map((invoice: any) => ({
          ...invoice,
          totalAmount: Number(invoice.totalAmount || 0),
          items: Array.isArray(invoice.items) ? invoice.items.map((item: any) => ({
            ...item,
            id: item.id || `item-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            product: item.product || "Produit inconnu",
            quantity: Number(item.quantity || 0),
            unitPrice: Number(item.unitPrice || 0),
            totalPrice: Number(item.totalPrice || item.quantity * item.unitPrice || 0)
          })) : [],
          customerName: invoice.customerName || "Client",
          customerEmail: invoice.customerEmail || "email@example.com"
        }));
        setInvoices(validInvoices);
      } else {
        // Si pas de factures en localStorage, créons quelques exemples
        const demoInvoices: Invoice[] = [
          {
            id: "INV-001",
            customerName: "Jean Dupont",
            customerEmail: "jean.dupont@example.com",
            date: new Date().toISOString(),
            dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
            status: "pending",
            totalAmount: 456.75,
            items: [
              {
                id: "item-1",
                product: "Grande Réserve 2020",
                quantity: 3,
                unitPrice: 24.50,
                totalPrice: 73.50
              },
              {
                id: "item-2",
                product: "Cuvée Élégance 2021",
                quantity: 2,
                unitPrice: 18.90,
                totalPrice: 37.80
              },
              {
                id: "item-3",
                product: "Rosé des Collines 2022",
                quantity: 4,
                unitPrice: 14.50,
                totalPrice: 58.00
              },
            ]
          },
          {
            id: "INV-002",
            customerName: "Marie Martin",
            customerEmail: "marie.martin@example.com",
            date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
            dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(),
            status: "paid",
            totalAmount: 287.45,
            items: [
              {
                id: "item-4",
                product: "Pétillant Nature 2021",
                quantity: 2,
                unitPrice: 22.00,
                totalPrice: 44.00
              },
              {
                id: "item-5",
                product: "Grande Réserve 2019",
                quantity: 1,
                unitPrice: 29.90,
                totalPrice: 29.90
              },
            ]
          }
        ];
        
        localStorage.setItem('invoices', JSON.stringify(demoInvoices));
        setInvoices(demoInvoices);
      }
      
      // API call (pour utilisation avec backend)
      // try {
      //   const fetchedInvoices = await fetchInvoices();
      //   setInvoices(fetchedInvoices);
      // } catch (error) {
      //   console.error('Erreur API:', error);
      //   toast.error("Erreur lors du chargement des factures depuis l'API");
      // }
    } catch (error) {
      console.error('Erreur:', error);
      toast.error("Erreur lors du chargement des factures");
    } finally {
      setLoading(false);
    }
  };
  
  const handleDownloadInvoice = (invoice: Invoice) => {
    try {
      setLoading(true);
      setDownloadingId(invoice.id);
      
      // Make sure invoice is properly formatted with all required fields
      const formattedInvoice = {
        ...invoice,
        items: Array.isArray(invoice.items) ? invoice.items.map(item => ({
          ...item,
          id: item.id || `item-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          quantity: Number(item.quantity || 0),
          unitPrice: Number(item.unitPrice || 0),
          totalPrice: Number(item.totalPrice || item.unitPrice * item.quantity || 0),
          product: item.product || "Produit inconnu"
        })) : [],
        totalAmount: Number(invoice.totalAmount || 0),
        customerName: invoice.customerName || "Client",
        customerEmail: invoice.customerEmail || "email@example.com",
        dueDate: invoice.dueDate || new Date().toISOString(),
        date: invoice.date || new Date().toISOString()
      };
      
      generateInvoicePDF(formattedInvoice);
      toast.success("Facture téléchargée avec succès");
      
      // API call (pour utilisation avec backend)
      // try {
      //   const response = await fetch(`/api/invoices/${invoice.id}/download`, {
      //     method: 'GET',
      //     headers: { 'Content-Type': 'application/json' }
      //   });
      //   
      //   if (!response.ok) throw new Error('Erreur lors du téléchargement');
      //   // Gérer le téléchargement du PDF renvoyé par le serveur
      //   // Par exemple, ouvrir un nouvel onglet avec le PDF ou lancer le téléchargement
      //   
      //   const blob = await response.blob();
      //   const url = window.URL.createObjectURL(blob);
      //   const a = document.createElement('a');
      //   a.href = url;
      //   a.download = `Facture_${invoice.id}.pdf`;
      //   document.body.appendChild(a);
      //   a.click();
      //   a.remove();
      // } catch (error) {
      //   console.error('Erreur API:', error);
      //   toast.error("Erreur lors du téléchargement de la facture depuis l'API");
      // }
    } catch (error) {
      console.error("Erreur lors du téléchargement de la facture", error);
      toast.error("Erreur lors du téléchargement de la facture");
    } finally {
      setLoading(false);
      setDownloadingId(null);
    }
  };
  
  const handleCreateInvoice = () => {
    // Cette fonction serait remplacée par un formulaire complet pour créer une facture
    toast.info("Cette fonctionnalité sera disponible prochainement");
    setShowNewInvoiceDialog(false);
    
    // API call (pour utilisation avec backend)
    // const newInvoice = {
    //   // Données issues du formulaire
    //   customerName: "Nouveau Client",
    //   customerEmail: "nouveau.client@example.com",
    //   totalAmount: 245.90,
    //   status: "pending",
    //   items: [
    //     {
    //       product: "Grande Réserve 2020",
    //       quantity: 2,
    //       unitPrice: 24.50,
    //       totalPrice: 49.00
    //     }
    //   ]
    // };
    // 
    // try {
    //   const createdInvoice = await createInvoice(newInvoice);
    //   setInvoices([createdInvoice, ...invoices]);
    //   toast.success("Facture créée avec succès");
    // } catch (error) {
    //   console.error('Erreur:', error);
    //   toast.error("Erreur lors de la création de la facture");
    // }
  };

  const handleDeleteInvoice = async (id: string) => {
    try {
      setLoading(true);
      
      await deleteInvoice(id);
      
      // Mettre à jour l'état local après suppression
      setInvoices(invoices.filter(invoice => invoice.id !== id));
      
      toast.success("Facture supprimée avec succès");
      
      // API call (pour utilisation avec backend)
      // try {
      //   await deleteInvoice(id);
      //   setInvoices(invoices.filter(invoice => invoice.id !== id));
      //   toast.success("Facture supprimée avec succès");
      // } catch (error) {
      //   console.error('Erreur API:', error);
      //   toast.error("Erreur lors de la suppression de la facture");
      // }
    } catch (error) {
      console.error("Erreur:", error);
      toast.error("Erreur lors de la suppression de la facture");
    } finally {
      setLoading(false);
      setInvoiceToDelete(null);
    }
  };
  
  const filteredInvoices = invoices
    .filter(invoice => {
      // Make sure we have customerName and id before trying to call toLowerCase()
      const nameMatch = invoice.customerName ? invoice.customerName.toLowerCase().includes(searchTerm.toLowerCase()) : false;
      const idMatch = invoice.id ? invoice.id.toLowerCase().includes(searchTerm.toLowerCase()) : false;
      
      return (nameMatch || idMatch) && (filter === "all" || invoice.status === filter);
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-6 w-full max-w-full">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Gestion des Factures</h1>
        
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Rechercher une facture..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 w-64"
            />
          </div>
          
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[180px]">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <SelectValue placeholder="Filtrer par statut" />
              </div>
            </SelectTrigger>
            <SelectContent className="dark:bg-gray-900">
              <SelectGroup>
                <SelectLabel>Statut</SelectLabel>
                <SelectItem value="all">Tous</SelectItem>
                <SelectItem value="paid">Payées</SelectItem>
                <SelectItem value="pending">En attente</SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
          
          <Button onClick={() => setShowNewInvoiceDialog(true)}>
            <Plus className="mr-1 h-4 w-4" /> Nouvelle facture
          </Button>
        </div>
      </div>
      
      {filteredInvoices.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">Aucune facture trouvée</p>
        </div>
      ) : (
        <div className="grid gap-4 w-full max-w-full">
          {filteredInvoices.map((invoice) => (
            <Card key={invoice.id} className="w-full">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle>Facture #{invoice.id}</CardTitle>
                  <Badge variant={invoice.status === 'paid' ? 'default' : 'outline'}>
                    {invoice.status === 'paid' ? 'Payée' : 'En attente'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm font-semibold">Client</p>
                    <p className="text-sm">{invoice.customerName || "Client"}</p>
                    <p className="text-sm text-muted-foreground">{invoice.customerEmail || "email@example.com"}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Dates</p>
                    <p className="text-sm">Émission: {invoice.date ? new Date(invoice.date).toLocaleDateString() : "N/A"}</p>
                    <p className="text-sm">Échéance: {invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : "N/A"}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Montant</p>
                    <p className="text-xl font-bold text-wine">{Number(invoice.totalAmount).toFixed(2)} €</p>
                  </div>
                </div>
                
                <div className="border-t border-border mt-4 pt-4">
                  <p className="text-sm font-semibold mb-2">Détails</p>
                  <div className="relative overflow-x-auto">
                    <table className="w-full text-sm text-left">
                      <thead className="text-xs uppercase bg-muted">
                        <tr>
                          <th scope="col" className="px-4 py-2">Produit</th>
                          <th scope="col" className="px-4 py-2 text-center">Quantité</th>
                          <th scope="col" className="px-4 py-2 text-right">Prix unitaire</th>
                          <th scope="col" className="px-4 py-2 text-right">Montant</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Array.isArray(invoice.items) && invoice.items.map((item) => (
                          <tr key={item.id} className="border-b">
                            <td className="px-4 py-2">{item.product}</td>
                            <td className="px-4 py-2 text-center">{Number(item.quantity).toString()}</td>
                            <td className="px-4 py-2 text-right">{Number(item.unitPrice).toFixed(2)} €</td>
                            <td className="px-4 py-2 text-right font-medium">{Number(item.totalPrice).toFixed(2)} €</td>
                          </tr>
                        ))}
                        <tr className="font-bold">
                          <td className="px-4 py-2" colSpan={3}>Total</td>
                          <td className="px-4 py-2 text-right">{Number(invoice.totalAmount).toFixed(2)} €</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  
                  <div className="mt-4 flex justify-end gap-2">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          disabled={loading}
                        >
                          Supprimer
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Êtes-vous sûr ?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Cette action ne peut pas être annulée. La facture sera définitivement supprimée.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Annuler</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => handleDeleteInvoice(invoice.id)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Supprimer
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                    
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex items-center gap-2"
                      onClick={() => handleDownloadInvoice(invoice)}
                      disabled={loading && downloadingId === invoice.id}
                    >
                      <Download className="h-4 w-4" />
                      {loading && downloadingId === invoice.id ? "Génération en cours..." : "Télécharger PDF"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* Dialog pour créer une nouvelle facture */}
      <Dialog open={showNewInvoiceDialog} onOpenChange={setShowNewInvoiceDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Créer une nouvelle facture</DialogTitle>
            <DialogDescription>
              Remplissez le formulaire pour créer une nouvelle facture.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 text-center">
            <p className="text-muted-foreground">
              Cette fonctionnalité sera disponible prochainement.
            </p>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowNewInvoiceDialog(false)}
            >
              Annuler
            </Button>
            <Button onClick={handleCreateInvoice}>
              Créer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FacturesPage;
