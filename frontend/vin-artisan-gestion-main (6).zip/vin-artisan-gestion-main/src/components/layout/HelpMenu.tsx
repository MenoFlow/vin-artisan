
import { useState } from 'react';
import { HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useRoleAccess } from '@/hooks/useRoleAccess';

const HelpMenu = () => {
  const { isAdmin } = useRoleAccess();
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="flex items-center gap-2 w-full justify-start">
          <HelpCircle className="h-5 w-5" />
          <span>Aide</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Centre d'aide VinExpert</DialogTitle>
          <DialogDescription>
            Guide complet d'utilisation de la plateforme VinExpert
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue={isAdmin ? "admin" : "client"}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="client">Client</TabsTrigger>
            <TabsTrigger value="admin" disabled={!isAdmin}>Administrateur</TabsTrigger>
          </TabsList>

          <TabsContent value="client" className="space-y-4 mt-4">
            <div>
              <h3 className="font-medium text-lg mb-2">Navigation</h3>
              <p className="text-muted-foreground">
                Utilisez la barre latérale pour accéder aux différentes sections de la plateforme. Vous pouvez la réduire/agrandir avec le bouton situé sur son bord droit pour avoir plus d'espace de travail.
              </p>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Catalogue de produits</h3>
              <p className="text-muted-foreground">
                Parcourez notre sélection de vins dans la section Catalogue. Vous pouvez filtrer par type, cépage, millésime et prix pour trouver facilement ce que vous cherchez.
              </p>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Commander des produits</h3>
              <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                <li>Accédez au catalogue de produits</li>
                <li>Sélectionnez les produits qui vous intéressent</li>
                <li>Ajoutez-les à votre panier</li>
                <li>Vérifiez votre panier et ajustez les quantités si nécessaire</li>
                <li>Passez à la caisse et choisissez votre mode de livraison</li>
                <li>Procédez au paiement sécurisé</li>
              </ol>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Suivi de commande</h3>
              <p className="text-muted-foreground">
                Vous pouvez suivre l'état de vos commandes dans la section "Commandes" de votre tableau de bord. Différents statuts vous indiqueront où en est le traitement de votre commande :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li><span className="font-medium">En attente</span> - Votre commande a été reçue</li>
                <li><span className="font-medium">Traitée</span> - Votre commande est en cours de préparation</li>
                <li><span className="font-medium">Expédiée</span> - Votre commande a été expédiée</li>
                <li><span className="font-medium">Livrée</span> - Votre commande a été livrée</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Gestion du profil</h3>
              <p className="text-muted-foreground">
                Dans la section "Profil", vous pouvez :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Mettre à jour vos informations personnelles</li>
                <li>Gérer vos adresses de livraison</li>
                <li>Consulter l'historique de vos commandes</li>
                <li>Modifier votre mot de passe</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Paramètres</h3>
              <p className="text-muted-foreground">
                Dans la section "Paramètres", personnalisez votre expérience en ajustant vos préférences :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Choisissez le thème clair ou sombre</li>
                <li>Configurez vos préférences de notifications</li>
                <li>Ajustez vos paramètres de confidentialité</li>
                <li>Sélectionnez votre langue préférée</li>
              </ul>
            </div>
          </TabsContent>

          <TabsContent value="admin" className="space-y-4 mt-4">
            <div>
              <h3 className="font-medium text-lg mb-2">Tableau de bord</h3>
              <p className="text-muted-foreground">
                Le tableau de bord vous donne une vue d'ensemble de votre activité avec des indicateurs clés de performance, des graphiques de ventes et une liste des actions prioritaires.
              </p>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Gestion des cuvées</h3>
              <p className="text-muted-foreground">
                La section "Cuvées" vous permet de :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Ajouter de nouvelles cuvées au catalogue</li>
                <li>Modifier les informations et les prix des produits existants</li>
                <li>Gérer les niveaux de stock et définir des alertes</li>
                <li>Archiver les produits épuisés ou hors saison</li>
                <li>Organiser les produits par catégories et collections</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Traitement des commandes</h3>
              <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                <li>Visualisez les nouvelles commandes dans la section "Commandes"</li>
                <li>Vérifiez la disponibilité des produits en stock</li>
                <li>Validez la commande pour lancer la préparation</li>
                <li>Générez les documents d'expédition et les factures</li>
                <li>Marquez la commande comme expédiée une fois l'envoi effectué</li>
                <li>Suivez les livraisons et gérez les retours si nécessaire</li>
              </ol>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Gestion des clients</h3>
              <p className="text-muted-foreground">
                Dans la section "Clients", vous pouvez :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Consulter la base de données clients</li>
                <li>Voir l'historique des achats de chaque client</li>
                <li>Créer des segments de clientèle pour des campagnes ciblées</li>
                <li>Gérer les demandes de support et les réclamations</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Factures</h3>
              <p className="text-muted-foreground">
                La section "Factures" vous permet de :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Générer des factures pour chaque commande</li>
                <li>Suivre les paiements et les relances</li>
                <li>Exporter les données comptables</li>
                <li>Générer des rapports financiers</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Gestion de la production</h3>
              <p className="text-muted-foreground">
                Utilisez la section "Production" pour :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Planifier les cycles de production viticole</li>
                <li>Suivre les étapes de la vinification</li>
                <li>Enregistrer les analyses et les contrôles qualité</li>
                <li>Gérer les stocks de matières premières et de produits finis</li>
                <li>Optimiser les ressources et les processus</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Gestion du vignoble</h3>
              <p className="text-muted-foreground">
                Dans la section "Gestion Vignoble", vous pouvez :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Cartographier vos parcelles et suivre leur état</li>
                <li>Planifier les interventions (taille, traitements, vendanges)</li>
                <li>Enregistrer les observations et les données météorologiques</li>
                <li>Analyser les performances par cépage et par parcelle</li>
                <li>Gérer l'équipement et la main-d'œuvre</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Statistiques</h3>
              <p className="text-muted-foreground">
                La section "Statistiques" vous fournit des insights précieux sur :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Les tendances de ventes par période, produit et région</li>
                <li>Le comportement d'achat des clients</li>
                <li>Les performances marketing et le ROI des campagnes</li>
                <li>L'évolution de la production et les rendements</li>
                <li>Les prévisions et analyses prédictives</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium text-lg mb-2">Paramètres administratifs</h3>
              <p className="text-muted-foreground">
                Dans la section "Paramètres", en tant qu'administrateur, vous pouvez également :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4 mt-2">
                <li>Gérer les comptes utilisateurs et leurs permissions</li>
                <li>Configurer les paramètres généraux du système</li>
                <li>Définir les règles de tarification et de taxe</li>
                <li>Paramétrer les options d'expédition et de paiement</li>
                <li>Activer ou désactiver des fonctionnalités</li>
              </ul>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default HelpMenu;
