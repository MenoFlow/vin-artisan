
import { Navigate } from "react-router-dom";

const Index = () => {
  return <Navigate to="/auth" />;
};

export default Index;
