
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line, Legend } from 'recharts';
import { useEffect, useState } from "react";

// Interfaces for our data
interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  wine_type?: string;
}

interface Order {
  id: string;
  clientId: string;
  clientName: string;
  items: OrderItem[];
  total: number;
  date: string;
  status: 'pending' | 'processed' | 'shipped' | 'delivered' | 'cancelled';
}

interface Cuvee {
  id: string;
  name: string;
  type: string;
  year: number;
  price: number;
  stock: number;
  description: string;
  image: string;
}

// Interface pour les données par type de vin
interface WineTypeData {
  quarter: string;
  Rouge: number;
  Blanc: number;
  Rosé: number;
  Pétillant: number;
  [key: string]: string | number;
}

const StatistiquesPage = () => {
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  const [quarterlyData, setQuarterlyData] = useState<WineTypeData[]>([]);
  
  useEffect(() => {
    // Fonction pour charger les données de statistiques
    const loadStatisticsData = async () => {
      try {
        // API calls (commentés, à utiliser avec le backend)
        // const salesResponse = await fetch('/api/stats/sales');
        // const wineTypesResponse = await fetch('/api/stats/wine-types');
        
        // if (!salesResponse.ok || !wineTypesResponse.ok) {
        //   throw new Error('Erreur lors de la récupération des statistiques');
        // }
        
        // const salesData = await salesResponse.json();
        // const wineTypesData = await wineTypesResponse.json();
        
        // setMonthlyData(salesData);
        // setQuarterlyData(wineTypesData);
        
        // Version locale avec les vraies données
        const generateSalesData = () => {
          const orders: Order[] = JSON.parse(localStorage.getItem('orders') || '[]');
          const monthlySales: Record<string, number> = {};
          const monthlyOrders: Record<string, number> = {};
          
          // If we have orders, process them
          if (orders.length > 0) {
            orders.forEach((order: Order) => {
              const date = new Date(order.date);
              const monthYear = `${date.toLocaleString('fr-FR', { month: 'short' })} ${date.getFullYear()}`;
              
              monthlySales[monthYear] = (monthlySales[monthYear] || 0) + order.total;
              monthlyOrders[monthYear] = (monthlyOrders[monthYear] || 0) + 1;
            });
            
            // Convert to array format for charts
            const data = Object.keys(monthlySales).map(month => ({
              month,
              ventes: monthlySales[month],
              commandes: monthlyOrders[month] || 0
            }));
            
            // Sort by date
            data.sort((a, b) => {
              const aDate = new Date(a.month.replace('janv.', 'janvier').replace('févr.', 'février').replace('avr.', 'avril').replace('juil.', 'juillet').replace('sept.', 'septembre').replace('oct.', 'octobre').replace('nov.', 'novembre').replace('déc.', 'décembre'));
              const bDate = new Date(b.month.replace('janv.', 'janvier').replace('févr.', 'février').replace('avr.', 'avril').replace('juil.', 'juillet').replace('sept.', 'septembre').replace('oct.', 'octobre').replace('nov.', 'novembre').replace('déc.', 'décembre'));
              return aDate.getTime() - bDate.getTime();
            });
            
            return data.slice(-6); // Last 6 months
          }
          
          return [];
        };
        
        const generateQuarterlyData = () => {
          const orders: Order[] = JSON.parse(localStorage.getItem('orders') || '[]');
          const cuvees: Cuvee[] = JSON.parse(localStorage.getItem('cuvees') || '[]');
          
          if (orders.length === 0) {
            return [];
          }
          
          // Group by quarters
          const now = new Date();
          const currentYear = now.getFullYear();
          const currentQuarter = Math.floor(now.getMonth() / 3) + 1;
          
          // Calculate previous quarter
          const prevQuarterYear = currentQuarter === 1 ? currentYear - 1 : currentYear;
          const prevQuarter = currentQuarter === 1 ? 4 : currentQuarter - 1;
          
          const quarterLabels = [
            `Q${prevQuarter} ${prevQuarterYear}`,
            `Q${currentQuarter} ${currentYear}`,
          ];
          
          // Initialize result structure with correct typing
          const result: WineTypeData[] = quarterLabels.map(quarter => {
            return {
              quarter,
              Rouge: 0,
              Blanc: 0,
              Rosé: 0,
              Pétillant: 0
            };
          });
          
          // Process orders
          orders.forEach((order: Order) => {
            const orderDate = new Date(order.date);
            const orderYear = orderDate.getFullYear();
            const orderQuarter = Math.floor(orderDate.getMonth() / 3) + 1;
            const orderQuarterLabel = `Q${orderQuarter} ${orderYear}`;
            
            // Skip if not in our quarters of interest
            if (!quarterLabels.includes(orderQuarterLabel)) {
              return;
            }
            
            // Find the quarter index
            const quarterIndex = quarterLabels.indexOf(orderQuarterLabel);
            if (quarterIndex === -1) return;
            
            // Process each item in the order
            order.items.forEach(item => {
              let type = "Autre";
              
              // Try to find the cuvee to get its type
              const cuvee = cuvees.find(c => c.id === item.id);
              if (cuvee && cuvee.type) {
                type = cuvee.type;
              } 
              // Or try to guess from the name
              else if (item.name) {
                const nameLower = item.name.toLowerCase();
                if (nameLower.includes("rouge")) type = "Rouge";
                else if (nameLower.includes("blanc")) type = "Blanc";
                else if (nameLower.includes("rosé") || nameLower.includes("rose")) type = "Rosé";
                else if (nameLower.includes("pétillant") || nameLower.includes("petillant") || nameLower.includes("champagne")) type = "Pétillant";
              }
              
              // Increment the sales for this type in this quarter
              if (["Rouge", "Blanc", "Rosé", "Pétillant"].includes(type)) {
                // Fix: Convert the property to a number before adding
                const currentValue = result[quarterIndex][type] as number;
                result[quarterIndex][type] = currentValue + (item.price * item.quantity);
              }
            });
          });
          
          return result;
        };
        
        const salesData = generateSalesData();
        setMonthlyData(salesData);
        
        const wineTypesData = generateQuarterlyData();
        setQuarterlyData(wineTypesData);
        
      } catch (error) {
        console.error('Erreur lors du chargement des statistiques:', error);
      }
    };
    
    loadStatisticsData();
  }, []);

  return (
    <div className="space-y-6 w-full">
      <h1 className="text-2xl font-bold">Statistiques</h1>
      
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Ventes Mensuelles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="ventes" name="Ventes (€)" fill="#7c3aed" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Évolution des Commandes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="commandes" name="Nombre de commandes" stroke="#882338" strokeWidth={2} dot={{ stroke: "#882338", strokeWidth: 2, r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Ventes par Catégorie de Vin</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={quarterlyData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="quarter" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Rouge" fill="#882338" />
                  <Bar dataKey="Blanc" fill="#f9e0ad" />
                  <Bar dataKey="Rosé" fill="#f4a4af" />
                  <Bar dataKey="Pétillant" fill="#d4af37" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default StatistiquesPage;
