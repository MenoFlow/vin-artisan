
import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { BarChart2, Package, ShoppingCart, Users, Wine } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, PieChart, Pie, Cell } from "recharts";
import { useRoleAccess } from "@/hooks/useRoleAccess";
import ClientDashboard from "./ClientDashboard";

// Type pour les commandes stockées
interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  wine_type?: string;
}

interface Order {
  id: string;
  clientId: string;
  clientName: string;
  items: OrderItem[];
  total: number;
  date: string;
  status: 'pending' | 'processed' | 'shipped' | 'delivered' | 'cancelled';
}

// Type pour les cuvées stockées
interface Cuvee {
  id: string;
  name: string;
  type: string;
  year: number;
  price: number;
  stock: number;
  description: string;
  image: string;
}

const COLORS = ['#722F37', '#A05195', '#D45087', '#F95D6A', '#FF7C43', '#FFA600'];

const Dashboard = () => {
  const { isClient } = useRoleAccess();
  const { user } = useAuth();
  
  // Si c'est un client, afficher le dashboard client
  if (isClient) {
    return <ClientDashboard />;
  }
  
  // Sinon, c'est le dashboard admin
  const [orders, setOrders] = useState<Order[]>([]);
  const [cuvees, setCuvees] = useState<Cuvee[]>([]);
  const [monthlySales, setMonthlySales] = useState<any[]>([]);
  const [wineTypeData, setWineTypeData] = useState<any[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);
  
  const loadDashboardData = () => {
    // Charger les données depuis le localStorage
    const savedOrders = localStorage.getItem('orders') || '[]';
    const parsedOrders: Order[] = JSON.parse(savedOrders);
    setOrders(parsedOrders);
    
    const savedCuvees = localStorage.getItem('cuvees') || '[]';
    const parsedCuvees: Cuvee[] = JSON.parse(savedCuvees);
    setCuvees(parsedCuvees);
    
    // Calculer les données de vente mensuelles
    const salesByMonth = new Map();
    parsedOrders.forEach(order => {
      const date = new Date(order.date);
      const monthYear = `${date.toLocaleString('default', { month: 'short' })}`;
      const currentSales = salesByMonth.get(monthYear) || 0;
      salesByMonth.set(monthYear, currentSales + order.total);
    });

    const salesData = Array.from(salesByMonth).map(([mois, ventes]) => ({
      mois,
      ventes
    }));
    setMonthlySales(salesData);

    // Calculer les données par type de vin
    const salesByType = new Map();
    parsedOrders.forEach(order => {
      order.items.forEach(item => {
        // Essayer de trouver le type dans le nom de l'article
        let type = "Autre";
        
        // Chercher dans les cuvées
        const cuvee = parsedCuvees.find(c => c.id === item.id);
        if (cuvee && cuvee.type) {
          type = cuvee.type;
        }
        // Sinon, essayer de déduire du nom
        else if (item.name && item.name.toLowerCase) {
          const nameLower = item.name.toLowerCase();
          if (nameLower.includes("rouge")) {
            type = "Rouge";
          } else if (nameLower.includes("blanc")) {
            type = "Blanc";
          } else if (nameLower.includes("rosé") || nameLower.includes("rose")) {
            type = "Rosé";
          } else if (nameLower.includes("pétillant") || nameLower.includes("petillant")) {
            type = "Pétillant";
          }
        }
        
        const currentValue = salesByType.get(type) || 0;
        salesByType.set(type, currentValue + (item.quantity * item.price));
      });
    });

    // Convertir en pourcentage du total
    const totalSales = Array.from(salesByType.values()).reduce((sum, val) => sum + val, 0);
    const typeData = Array.from(salesByType).map(([name, value]) => ({
      name, 
      value: totalSales > 0 ? Math.round((value / totalSales) * 100) : 0
    }));
    setWineTypeData(typeData);
  }

  // Calcul des statistiques
  const totalSales = orders.reduce((sum, order) => sum + order.total, 0);
  const activeCuvees = cuvees.filter(cuvee => cuvee.stock > 0).length;
  const pendingOrders = orders.filter(o => o.status === 'pending' || o.status === 'processed').length;
  const clientCount = new Set(orders.map(o => o.clientId)).size;

  return (
    <div className="w-full">
      <h1 className="text-2xl font-bold mb-6">Tableau de bord administrateur</h1>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Ventes totales</CardTitle>
            <ShoppingCart className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalSales.toFixed(2)}€</div>
            <p className="text-xs text-muted-foreground">Toutes périodes confondues</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Cuvées actives</CardTitle>
            <Wine className="h-5 w-5 text-wine" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCuvees}</div>
            <p className="text-xs text-muted-foreground">{cuvees.filter(c => c.stock > 0 && c.stock < 10).length} avec stock faible</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Commandes</CardTitle>
            <Package className="h-5 w-5 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orders.length}</div>
            <p className="text-xs text-muted-foreground">{pendingOrders} en attente de traitement</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Clients</CardTitle>
            <Users className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{clientCount}</div>
            <p className="text-xs text-muted-foreground">Nombre total de clients</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 mt-6">
        <Card>
          <CardHeader>
            <CardTitle>Ventes mensuelles</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {monthlySales.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlySales} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <Line type="monotone" dataKey="ventes" stroke="#722F37" strokeWidth={2} />
                  <CartesianGrid stroke="#ccc" strokeDasharray="5 5" />
                  <XAxis dataKey="mois" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value} €`, "Ventes"]} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full">
                <p className="text-muted-foreground">Aucune vente enregistrée</p>
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Répartition des ventes par type</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {wineTypeData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={wineTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {wineTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value}%`, "% des ventes"]} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full">
                <p className="text-muted-foreground">Aucune donnée disponible</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="mt-6">
        <Card>
          <CardHeader className="flex flex-row items-center">
            <CardTitle>Activités récentes</CardTitle>
          </CardHeader>
          <CardContent>
            {orders.length > 0 ? (
              <div className="space-y-4">
                {orders.slice(0, 5).map((order) => (
                  <div key={order.id} className="flex items-center">
                    <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                    <span className="flex-1">
                      Commande #{order.id.slice(0, 6)} - Client: {order.clientName}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(order.date).toLocaleDateString()}
                    </span>
                  </div>
                ))}
                {cuvees.filter(c => c.stock < 10 && c.stock > 0).slice(0, 3).map((cuvee) => (
                  <div key={cuvee.id} className="flex items-center">
                    <span className="w-2 h-2 rounded-full bg-amber-500 mr-2"></span>
                    <span className="flex-1">Stock faible sur "{cuvee.name}"</span>
                    <span className="text-xs text-muted-foreground">{cuvee.stock} restant(s)</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground">Aucune activité récente</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
