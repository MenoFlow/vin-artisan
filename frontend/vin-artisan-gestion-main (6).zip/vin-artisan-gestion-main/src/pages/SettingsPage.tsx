import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

interface UserSettings {
  language: string;
  timezone: string;
  emailNotifications: boolean;
  orderUpdates: boolean;
  marketing: boolean;
  theme: string;
  density: string;
  maintenance: boolean;
  registration: boolean;
  debug: boolean;
}

const defaultSettings: UserSettings = {
  language: "fr",
  timezone: "Europe/Paris",
  emailNotifications: false,
  orderUpdates: true,
  marketing: false,
  theme: "light",
  density: "comfortable",
  maintenance: false,
  registration: true,
  debug: false,
};

const SettingsPage = () => {
  const { user } = useAuth();
  const [settings, setSettings] = useState<UserSettings>(defaultSettings);

  useEffect(() => {
    // Load user settings from localStorage
    if (user) {
      const savedSettings = localStorage.getItem(`user-settings-${user.id}`);
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
    }
  }, [user]);

  const saveSettings = (newSettings: UserSettings) => {
    if (user) {
      localStorage.setItem(`user-settings-${user.id}`, JSON.stringify(newSettings));
      setSettings(newSettings);
      toast("Paramètre mis à jour", {
        description: "Votre paramètre a été mis à jour avec succès.",
      });
    }
  };

  const handleChange = (key: keyof UserSettings, value: any) => {
    const newSettings = { ...settings, [key]: value };
    saveSettings(newSettings);
  };

  if (!user) return null;

  return (
    <div className="w-full">
      <h1 className="text-2xl font-bold mb-6">Paramètres</h1>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="w-full md:w-auto grid grid-cols-2 md:grid-cols-4 gap-2">
          <TabsTrigger value="general">Général</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="appearance">Apparence</TabsTrigger>
          {user.role === "admin" && (
            <TabsTrigger value="admin">Administration</TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Paramètres généraux</CardTitle>
              <CardDescription>
                Configurez vos préférences générales
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="language">Langue</Label>
                  <p className="text-sm text-muted-foreground">Choisir la langue de l'interface</p>
                </div>
                <select 
                  id="language" 
                  className="bg-background border rounded px-2 py-1"
                  value={settings.language}
                  onChange={(e) => handleChange('language', e.target.value)}
                >
                  <option value="fr">Français</option>
                  <option value="en">English</option>
                </select>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="timezone">Fuseau horaire</Label>
                  <p className="text-sm text-muted-foreground">Choisir votre fuseau horaire</p>
                </div>
                <select 
                  id="timezone" 
                  className="bg-background border rounded px-2 py-1"
                  value={settings.timezone}
                  onChange={(e) => handleChange('timezone', e.target.value)}
                >
                  <option value="Europe/Paris">Paris (UTC+1)</option>
                  <option value="Europe/London">Londres (UTC)</option>
                </select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Paramètres de notifications</CardTitle>
              <CardDescription>
                Configurez comment et quand vous recevez des notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="email-notifs">Notifications par email</Label>
                  <p className="text-sm text-muted-foreground">Recevoir les notifications par email</p>
                </div>
                <Switch 
                  id="email-notifs" 
                  checked={settings.emailNotifications}
                  onCheckedChange={(checked) => handleChange('emailNotifications', checked)} 
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="order-updates">Mises à jour des commandes</Label>
                  <p className="text-sm text-muted-foreground">Recevoir des notifications pour les mises à jour de commandes</p>
                </div>
                <Switch 
                  id="order-updates" 
                  checked={settings.orderUpdates}
                  onCheckedChange={(checked) => handleChange('orderUpdates', checked)} 
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="marketing">Communications marketing</Label>
                  <p className="text-sm text-muted-foreground">Recevoir des emails promotionnels et newsletters</p>
                </div>
                <Switch 
                  id="marketing" 
                  checked={settings.marketing}
                  onCheckedChange={(checked) => handleChange('marketing', checked)} 
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Paramètres d'apparence</CardTitle>
              <CardDescription>
                Personnalisez l'apparence de l'interface
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="theme">Thème</Label>
                  <p className="text-sm text-muted-foreground">Changer le thème de l'application</p>
                </div>
                <select 
                  id="theme" 
                  className="bg-background border rounded px-2 py-1"
                  value={settings.theme}
                  onChange={(e) => {
                    handleChange('theme', e.target.value);
                    // Apply theme change
                    document.documentElement.classList.toggle('dark', e.target.value === 'dark');
                    document.documentElement.classList.toggle('light', e.target.value === 'light');
                    localStorage.setItem('theme', e.target.value);
                  }}
                >
                  <option value="light">Clair</option>
                  <option value="dark">Sombre</option>
                  <option value="system">Système</option>
                </select>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="density">Densité d'affichage</Label>
                  <p className="text-sm text-muted-foreground">Ajuster l'espacement entre les éléments</p>
                </div>
                <select 
                  id="density" 
                  className="bg-background border rounded px-2 py-1"
                  value={settings.density}
                  onChange={(e) => handleChange('density', e.target.value)}
                >
                  <option value="comfortable">Confortable</option>
                  <option value="compact">Compact</option>
                </select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {user.role === "admin" && (
          <TabsContent value="admin" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Paramètres d'administration</CardTitle>
                <CardDescription>
                  Configurez les paramètres réservés aux administrateurs
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="maintenance">Mode maintenance</Label>
                    <p className="text-sm text-muted-foreground">Activer le mode maintenance du site</p>
                  </div>
                  <Switch 
                    id="maintenance" 
                    checked={settings.maintenance}
                    onCheckedChange={(checked) => handleChange('maintenance', checked)} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="registration">Inscription utilisateur</Label>
                    <p className="text-sm text-muted-foreground">Autoriser les nouvelles inscriptions</p>
                  </div>
                  <Switch 
                    id="registration" 
                    checked={settings.registration}
                    onCheckedChange={(checked) => handleChange('registration', checked)} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="debug">Mode debug</Label>
                    <p className="text-sm text-muted-foreground">Activer les journaux de débogage avancés</p>
                  </div>
                  <Switch 
                    id="debug" 
                    checked={settings.debug}
                    onCheckedChange={(checked) => handleChange('debug', checked)} 
                  />
                </div>
                
                <div className="border-t pt-4 mt-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">Gestion des pays partenaires</h3>
                      <p className="text-sm text-muted-foreground">Gérer les pays autorisés pour les commandes</p>
                    </div>
                    <Button asChild variant="outline">
                      <Link to="/partner-countries" className="flex items-center gap-2">
                        Gérer <ExternalLink className="h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default SettingsPage;
