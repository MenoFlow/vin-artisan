
import { useState, useEffect } from "react";
import { Bell, BellOff } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface Notification {
  id: number;
  type: string;
  message: string;
  date: string;
  read: boolean;
}

const NotificationsMenu = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [hasUnread, setHasUnread] = useState(false);

  useEffect(() => {
    // Charger les notifications depuis localStorage
    const loadNotifications = () => {
      const savedNotifications = localStorage.getItem('notifications');
      if (savedNotifications) {
        const parsedNotifications = JSON.parse(savedNotifications);
        setNotifications(parsedNotifications);
        
        // Vérifier s'il y a des notifications non lues
        const unreadExists = parsedNotifications.some((notif: Notification) => !notif.read);
        setHasUnread(unreadExists);
      }
    };
    
    loadNotifications();
    
    // Mettre en place un intervalle pour vérifier les nouvelles notifications
    const interval = setInterval(loadNotifications, 10000);
    
    return () => clearInterval(interval);
  }, []);
  
  const markAllAsRead = () => {
    const updatedNotifications = notifications.map(notification => ({
      ...notification,
      read: true
    }));
    
    setNotifications(updatedNotifications);
    setHasUnread(false);
    localStorage.setItem('notifications', JSON.stringify(updatedNotifications));
  };
  
  const markAsRead = (id: number) => {
    const updatedNotifications = notifications.map(notification => 
      notification.id === id ? { ...notification, read: true } : notification
    );
    
    setNotifications(updatedNotifications);
    const stillUnread = updatedNotifications.some(notif => !notif.read);
    setHasUnread(stillUnread);
    localStorage.setItem('notifications', JSON.stringify(updatedNotifications));
  };
  
  const clearAllNotifications = () => {
    setNotifications([]);
    setHasUnread(false);
    localStorage.setItem('notifications', JSON.stringify([]));
  };

  const getRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "À l'instant";
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    
    const diffHrs = Math.floor(diffMins / 60);
    if (diffHrs < 24) return `Il y a ${diffHrs} h`;
    
    const diffDays = Math.floor(diffHrs / 24);
    if (diffDays < 7) return `Il y a ${diffDays} j`;
    
    return date.toLocaleDateString();
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          {hasUnread ? (
            <>
              <Bell className="h-5 w-5" />
              <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full" />
            </>
          ) : (
            <BellOff className="h-5 w-5" />
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel className="flex justify-between items-center">
          <span>Notifications</span>
          {notifications.length > 0 && (
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                Tout marquer comme lu
              </Button>
              <Button variant="ghost" size="sm" onClick={clearAllNotifications}>
                Effacer tout
              </Button>
            </div>
          )}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {notifications.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground">
            Aucune notification
          </div>
        ) : (
          notifications
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .slice(0, 10)
            .map(notification => (
              <DropdownMenuItem 
                key={notification.id} 
                className="p-4 cursor-default"
                onClick={() => markAsRead(notification.id)}
              >
                <div className={`space-y-1 w-full ${!notification.read ? 'font-medium' : ''}`}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      {notification.type === 'order' && 'Nouvelle commande'}
                      {notification.type === 'registration' && 'Nouvelle inscription'}
                      {notification.type === 'stock' && 'Alerte stock'}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {getRelativeTime(notification.date)}
                    </span>
                  </div>
                  <p className="text-sm">{notification.message}</p>
                  {!notification.read && (
                    <Badge variant="outline" className="mt-1 bg-blue-50 text-blue-600">
                      Nouveau
                    </Badge>
                  )}
                </div>
              </DropdownMenuItem>
            ))
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default NotificationsMenu;
