
import { LoginCredentials, RegisterData, User } from "@/types/user";

const USERS_STORAGE_KEY = "vin-artisan-users";
const CURRENT_USER_KEY = "vin-artisan-current-user";

// Récupérer les utilisateurs du localStorage
const getUsers = (): User[] => {
  const usersJson = localStorage.getItem(USERS_STORAGE_KEY);
  return usersJson ? JSON.parse(usersJson) : [];
};

// Enregistrer les utilisateurs dans le localStorage
const saveUsers = (users: User[]) => {
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
};

// Vérifier si l'utilisateur existe déjà
const userExists = (email: string): boolean => {
  const users = getUsers();
  return users.some((user) => user.email === email);
};

// Enregistrer un nouvel utilisateur
export const registerUser = (userData: RegisterData): User | null => {
  if (userExists(userData.email)) {
    return null; // L'email est déjà utilisé
  }

  const newUser: User = {
    id: Date.now().toString(),
    email: userData.email,
    name: userData.name,
    role: "client", // Par défaut, les nouveaux utilisateurs sont des clients
    createdAt: new Date().toISOString(),
  };

  // Ajouter l'utilisateur à la liste
  const users = getUsers();
  users.push(newUser);
  saveUsers(users);

  // Sauvegarder le mot de passe séparément pour plus de sécurité
  // Dans une application réelle, on utiliserait un hachage du mot de passe
  localStorage.setItem(`password-${newUser.id}`, userData.password);

  return newUser;
};

// Connecter un utilisateur
export const loginUser = (credentials: LoginCredentials): User | null => {
  const users = getUsers();
  const user = users.find((user) => user.email === credentials.email);

  if (!user) {
    return null; // Utilisateur non trouvé
  }

  const storedPassword = localStorage.getItem(`password-${user.id}`);
  if (storedPassword !== credentials.password) {
    return null; // Mot de passe incorrect
  }

  // Stocker l'utilisateur courant dans le localStorage
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  return user;
};

// Déconnecter l'utilisateur
export const logoutUser = () => {
  localStorage.removeItem(CURRENT_USER_KEY);
};

// Récupérer l'utilisateur courant
export const getCurrentUser = (): User | null => {
  const userJson = localStorage.getItem(CURRENT_USER_KEY);
  return userJson ? JSON.parse(userJson) : null;
};

// Changer le mot de passe d'un utilisateur
export const changeUserPassword = (userId: string, currentPassword: string, newPassword: string): boolean => {
  const storedPassword = localStorage.getItem(`password-${userId}`);
  
  // Vérifier que le mot de passe actuel est correct
  if (storedPassword !== currentPassword) {
    return false;
  }
  
  // Mettre à jour le mot de passe
  localStorage.setItem(`password-${userId}`, newPassword);
  return true;
};

// Supprimer un compte utilisateur
export const deleteUserAccount = (userId: string): boolean => {
  const users = getUsers();
  const userIndex = users.findIndex(user => user.id === userId);
  
  if (userIndex === -1) {
    return false;
  }
  
  // Supprimer l'utilisateur de la liste
  users.splice(userIndex, 1);
  saveUsers(users);
  
  // Supprimer le mot de passe associé
  localStorage.removeItem(`password-${userId}`);
  
  // Si c'est l'utilisateur actuel, déconnexion
  const currentUser = getCurrentUser();
  if (currentUser && currentUser.id === userId) {
    logoutUser();
  }
  
  return true;
};

// Initialiser quelques utilisateurs pour les tests
export const initializeTestUsers = () => {
  if (getUsers().length === 0) {
    const adminUser: User = {
      id: "1",
      email: "admin@vinartisan.fr",
      name: "Admin",
      role: "admin",
      createdAt: new Date().toISOString(),
    };

    const clientUser: User = {
      id: "2",
      email: "client@example.com",
      name: "Client Test",
      role: "client",
      createdAt: new Date().toISOString(),
    };

    saveUsers([adminUser, clientUser]);
    localStorage.setItem(`password-1`, "admin123");
    localStorage.setItem(`password-2`, "client123");
  }
};
